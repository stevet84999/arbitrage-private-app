# AI Arbitrage Scanner

Private Streamlit dashboard for scanning live bookmaker odds and finding arbitrage opportunities.

## Streamlit Cloud setup

Add this in Manage app → Settings → Secrets:

```toml
ODDS_API_KEY = "your_real_key_here"
```

Optional Telegram:

```toml
TELEGRAM_BOT_TOKEN = "your_bot_token"
TELEGRAM_CHAT_ID = "your_chat_id"
```

Main file: `app.py`.
