import os

import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()


def get_secret(name: str, default: str = "") -> str:
    try:
        value = st.secrets.get(name, "")
    except Exception:
        value = ""

    if not value:
        value = os.getenv(name, default)

    return str(value).strip()


def telegram_enabled() -> bool:
    return bool(get_secret("TELEGRAM_BOT_TOKEN") and get_secret("TELEGRAM_CHAT_ID"))


def send_telegram_message(message: str) -> None:
    bot_token = get_secret("TELEGRAM_BOT_TOKEN")
    chat_id = get_secret("TELEGRAM_CHAT_ID")

    if not bot_token or not chat_id:
        return

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }

    response = requests.post(url, json=payload, timeout=20)
    response.raise_for_status()


def format_opportunity(arb, total_stake: float, stakes: dict) -> str:
    lines = [
        "Arbitrage Found",
        f"Sport: {arb.sport}",
        f"Event: {arb.event}",
        f"Start: {arb.commence_time}",
        f"Profit margin: {arb.profit_margin}%",
        f"Total stake: £{total_stake:.2f}",
        "",
    ]

    for outcome, data in stakes.items():
        lines.append(
            f"{outcome}: £{data['stake']} at {data['odds']} with {data['bookmaker']}"
        )

    return "\n".join(lines)
