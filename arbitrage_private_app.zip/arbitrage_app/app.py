import os
import hmac
from datetime import datetime
from typing import Dict, List, Any, Optional

import pandas as pd
import requests
import streamlit as st

API_BASE = "https://api.the-odds-api.com/v4/sports"
DEFAULT_SPORTS = {
    "Football - EPL": "soccer_epl",
    "Football - Champions League": "soccer_uefa_champs_league",
    "Football - England Championship": "soccer_efl_champ",
    "Tennis - ATP": "tennis_atp",
    "Tennis - WTA": "tennis_wta",
    "Basketball - NBA": "basketball_nba",
    "Rugby League - NRL": "rugbyleague_nrl",
}
PREFERRED_BOOKMAKERS = {"coral", "ladbrokes", "betfred"}

SAMPLE_EVENTS = [
    {
        "sport_title": "Football 1X2 - Demo",
        "commence_time": "2026-06-18T18:00:00Z",
        "home_team": "Arsenal",
        "away_team": "Chelsea",
        "bookmakers": [
            {"key": "ladbrokes", "title": "Ladbrokes", "markets": [{"key": "h2h", "outcomes": [
                {"name": "Arsenal", "price": 2.40}, {"name": "Draw", "price": 3.60}, {"name": "Chelsea", "price": 3.80}
            ]}]},
            {"key": "coral", "title": "Coral", "markets": [{"key": "h2h", "outcomes": [
                {"name": "Arsenal", "price": 2.20}, {"name": "Draw", "price": 3.95}, {"name": "Chelsea", "price": 3.50}
            ]}]},
            {"key": "betfred", "title": "Betfred", "markets": [{"key": "h2h", "outcomes": [
                {"name": "Arsenal", "price": 2.15}, {"name": "Draw", "price": 3.70}, {"name": "Chelsea", "price": 4.20}
            ]}]},
        ],
    },
    {
        "sport_title": "Tennis - Demo",
        "commence_time": "2026-06-18T13:00:00Z",
        "home_team": "Player A",
        "away_team": "Player B",
        "bookmakers": [
            {"key": "coral", "title": "Coral", "markets": [{"key": "h2h", "outcomes": [
                {"name": "Player A", "price": 2.20}, {"name": "Player B", "price": 1.85}
            ]}]},
            {"key": "betfred", "title": "Betfred", "markets": [{"key": "h2h", "outcomes": [
                {"name": "Player A", "price": 1.95}, {"name": "Player B", "price": 2.20}
            ]}]},
        ],
    },
]


def secret_value(name: str, default: Optional[str] = None) -> Optional[str]:
    env = os.getenv(name)
    if env:
        return env
    try:
        return st.secrets.get(name, default)
    except Exception:
        return default


def require_login() -> bool:
    password = secret_value("APP_PASSWORD", "change-me")
    if not password or password == "change-me":
        st.warning("Private mode is active, but APP_PASSWORD is not set. Using temporary password: change-me")
    if st.session_state.get("authenticated"):
        return True
    st.title("Private Arbitrage Betting App")
    entered = st.text_input("Password", type="password")
    if st.button("Unlock"):
        if hmac.compare_digest(entered, password):
            st.session_state["authenticated"] = True
            st.rerun()
        st.error("Incorrect password")
    return False


def get_api_key() -> Optional[str]:
    return secret_value("ODDS_API_KEY")


@st.cache_data(ttl=60)
def fetch_odds(sport_key: str, api_key: str, regions: str = "uk", markets: str = "h2h") -> List[Dict[str, Any]]:
    response = requests.get(
        f"{API_BASE}/{sport_key}/odds",
        params={"apiKey": api_key, "regions": regions, "markets": markets, "oddsFormat": "decimal"},
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def best_prices_for_event(event: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    best: Dict[str, Dict[str, Any]] = {}
    for bookmaker in event.get("bookmakers", []):
        for market in bookmaker.get("markets", []):
            if market.get("key") != "h2h":
                continue
            for outcome in market.get("outcomes", []):
                name = outcome.get("name")
                price = float(outcome.get("price", 0))
                if not name or price <= 1:
                    continue
                current = best.get(name)
                if current is None or price > current["odds"]:
                    best[name] = {
                        "odds": price,
                        "bookmaker": bookmaker.get("title", bookmaker.get("key", "Unknown")),
                        "bookmaker_key": bookmaker.get("key", "unknown"),
                    }
    return best


def calculate_arbitrage(best: Dict[str, Dict[str, Any]], bankroll: float) -> Optional[Dict[str, Any]]:
    if len(best) < 2:
        return None
    inv_sum = sum(1 / v["odds"] for v in best.values())
    if inv_sum >= 1:
        return None
    guaranteed_return = bankroll / inv_sum
    profit = guaranteed_return - bankroll
    stakes = []
    for outcome, data in best.items():
        stake = guaranteed_return / data["odds"]
        stakes.append({
            "Outcome": outcome,
            "Bookmaker": data["bookmaker"],
            "Odds": round(data["odds"], 3),
            "Stake £": round(stake, 2),
            "Return £": round(stake * data["odds"], 2),
        })
    return {
        "profit_pct": (profit / bankroll) * 100,
        "profit": profit,
        "return": guaranteed_return,
        "stakes": stakes,
    }


def scan_events(events: List[Dict[str, Any]], bankroll: float, min_profit: float, preferred_only: bool) -> pd.DataFrame:
    rows = []
    for event in events:
        best = best_prices_for_event(event)
        arb = calculate_arbitrage(best, bankroll)
        if not arb or arb["profit_pct"] < min_profit:
            continue
        preferred_hit = any(s["Bookmaker"].lower() in PREFERRED_BOOKMAKERS for s in arb["stakes"])
        if preferred_only and not preferred_hit:
            continue
        rows.append({
            "Sport": event.get("sport_title", "Unknown"),
            "Event": f"{event.get('home_team', 'Home')} vs {event.get('away_team', 'Away')}",
            "Start": event.get("commence_time", ""),
            "Profit %": round(arb["profit_pct"], 2),
            "Profit £": round(arb["profit"], 2),
            "Return £": round(arb["return"], 2),
            "Bookmakers": ", ".join(sorted({s["Bookmaker"] for s in arb["stakes"]})),
            "Stake Plan": " | ".join(f"{s['Outcome']}: £{s['Stake £']} @ {s['Odds']} ({s['Bookmaker']})" for s in arb["stakes"]),
        })
    return pd.DataFrame(rows).sort_values("Profit %", ascending=False) if rows else pd.DataFrame()


st.set_page_config(page_title="Private Arbitrage Betting App", page_icon="🔐", layout="wide")
if not require_login():
    st.stop()

st.title("🔐 Private Arbitrage Betting Dashboard")
st.caption("Private scanner for 2-way and 3-way h2h arbitrage. Always verify odds before placing bets.")

with st.sidebar:
    st.header("Scanner Settings")
    bankroll = st.number_input("Bankroll per opportunity (£)", min_value=10.0, value=1000.0, step=10.0)
    min_profit = st.slider("Minimum profit %", 0.0, 20.0, 1.0, 0.1)
    preferred_only = st.checkbox("Only Coral / Ladbrokes / Betfred opportunities", value=False)
    use_demo = st.toggle("Use demo data", value=True)
    selected_sports = st.multiselect("Sports", list(DEFAULT_SPORTS.keys()), default=["Football - EPL", "Tennis - ATP", "Basketball - NBA"])
    if st.button("Refresh odds"):
        st.cache_data.clear()

api_key = get_api_key()
events: List[Dict[str, Any]] = []
errors = []

if use_demo:
    events = SAMPLE_EVENTS
elif not api_key:
    st.error("ODDS_API_KEY is missing. Add it to Streamlit Secrets or your .env/environment.")
else:
    for sport_name in selected_sports:
        try:
            events.extend(fetch_odds(DEFAULT_SPORTS[sport_name], api_key))
        except Exception as exc:
            errors.append(f"{sport_name}: {exc}")

for error in errors:
    st.warning(error)

results = scan_events(events, bankroll, min_profit, preferred_only) if events else pd.DataFrame()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Events scanned", len(events))
c2.metric("Arbs found", len(results))
c3.metric("Best profit %", "0" if results.empty else f"{results.iloc[0]['Profit %']}%")
c4.metric("Bankroll", f"£{bankroll:,.0f}")

if results.empty:
    st.info("No opportunities found for these settings.")
else:
    st.subheader("Arbitrage Opportunities")
    st.dataframe(results, use_container_width=True, hide_index=True)
    st.download_button("Download CSV", results.to_csv(index=False).encode("utf-8"), "arbitrage_opportunities.csv", "text/csv")

st.subheader("Manual Stake Calculator")
manual_odds = st.text_input("Decimal odds separated by commas", "2.40,3.95,4.20")
manual_bankroll = st.number_input("Calculator bankroll (£)", min_value=1.0, value=1000.0, step=10.0, key="manual_bankroll")
try:
    odds = [float(x.strip()) for x in manual_odds.split(",") if x.strip()]
    manual_best = {f"Outcome {i + 1}": {"odds": odd, "bookmaker": "Manual", "bookmaker_key": "manual"} for i, odd in enumerate(odds)}
    arb = calculate_arbitrage(manual_best, manual_bankroll)
    if arb:
        st.success(f"Arbitrage found: {arb['profit_pct']:.2f}% profit / £{arb['profit']:.2f} profit")
        st.table(pd.DataFrame(arb["stakes"]))
    else:
        st.warning("No arbitrage for these odds.")
except ValueError:
    st.error("Enter valid odds, e.g. 2.10, 1.95")

st.caption(f"Last checked: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
