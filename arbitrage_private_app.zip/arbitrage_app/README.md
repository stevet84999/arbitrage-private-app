# Private Arbitrage Betting App

A private Streamlit dashboard for finding arbitrage opportunities from bookmaker odds.

## Files

- `app.py` - main Streamlit app
- `requirements.txt` - Python dependencies
- `.env.example` - example secrets

## Run locally

```bash
pip install -r requirements.txt
export ODDS_API_KEY="your_api_key"
export APP_PASSWORD="your_private_password"
streamlit run app.py
```

On Windows PowerShell:

```powershell
$env:ODDS_API_KEY="your_api_key"
$env:APP_PASSWORD="your_private_password"
streamlit run app.py
```

## Streamlit Cloud private setup

1. Upload these files to a private GitHub repository.
2. Create a Streamlit Cloud app from the repository.
3. In Streamlit Cloud, open **App settings → Secrets**.
4. Add:

```toml
ODDS_API_KEY="your_api_key"
APP_PASSWORD="your_private_password"
```

5. Deploy the app.

## Private features

- Password gate before dashboard access.
- API key stored only in environment variables or Streamlit Secrets.
- Demo mode for testing without using API credits.
- Live Odds API integration.
- 2-way and 3-way H2H arbitrage detection.
- Stake calculator and CSV export.

## Notes

Always verify odds manually before placing bets. Odds can move quickly, and bookmakers may limit, void, or reject bets.
